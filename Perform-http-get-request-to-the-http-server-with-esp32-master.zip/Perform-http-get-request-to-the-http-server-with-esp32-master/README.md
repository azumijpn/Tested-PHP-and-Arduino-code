# Perform-http-get-request-to-the-http-server-with-esp32
send dht11 sensor data to mysql using php get api
