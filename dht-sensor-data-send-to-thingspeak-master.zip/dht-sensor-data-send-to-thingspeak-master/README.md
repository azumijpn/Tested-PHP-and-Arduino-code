# dht-sensor-data-send-to-thingspeak
#include<WiFi.h>
#include <ThingSpeak.h>;
#include <WiFiClient.h>;
#include "DHT.h"
#define DHTTYPE DHT11  

int DHTPin = 12; 
DHT dht(DHTPin, DHTTYPE);
int val;               
float Temperature;
float Humidity;
const char* ssid = "."; 
const char* password = "asdfghjklkjh";
const char* server = "api.thingspeak.com";
WiFiClient client;
unsigned long myChannelNumber = 905295; 
const char * myWriteAPIKey = "F49NHQRACUC6XIS9"; 
 
 
void setup() {
  Serial.begin(115200);
  delay(100);
  WiFi.begin(ssid,password);
  ThingSpeak.begin(client);
  pinMode(DHTPin, INPUT);
  
}
void loop() {
Temperature = dht.readTemperature(); 
//val=Temperature;
Serial.print("DHT = ");
Serial.print(Temperature);
Serial.println(" ");
delay(1000);
ThingSpeak.writeField(myChannelNumber, 1,Temperature, myWriteAPIKey);
delay(100);

}
