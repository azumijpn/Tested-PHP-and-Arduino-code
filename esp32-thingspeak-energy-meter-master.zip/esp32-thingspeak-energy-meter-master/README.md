# esp32-thingspeak-energy-meter
#include<WiFi.h>
#include <ThingSpeak.h>;
#include <WiFiClient.h>;
const char* ssid = "."; 
const char* password = "asdfghjklkjh";
const char* server = "api.thingspeak.com";
WiFiClient client;
unsigned long myChannelNumber = 944606; 
const char * myWriteAPIKey = "T5BIDVQ1Q4ZTMVRP";

char Energy_Meter_Raw_Serial_Buffer_Data[60];
float Energy_Meter_Kwh = 0.00;
float Energy_Meter_Current = 0.00;
float Energy_Meter_Watt = 0.00;
float Energy_Meter_Voltage = 0.00;
int  Energy_Meter_Ready_Status_flag = 0;

union {
  uint32_t i;
  float f;
} data;

void setup() {
  Serial.begin(9600);
  delay(10);
  Serial1.begin(9600);
  delay(10);
  WiFi.begin(ssid,password);
  ThingSpeak.begin(client);
}
void loop() {
     // Serial.println(F("reading energy meter"));
        while (!Serial1.available());
        if ( Serial1.read() == 'E') {
          while (!Serial1.available());
          if (Serial1.read() == 'T')  {
            while (!Serial1.available());
            if (Serial1.read() == 'P')  {
              Serial.println("ETP reading now");
              data_store();
              delay(100);
            }
          }
        }
    Energy_Meter_Ready_Status_flag = 0;
  }
void data_store()
{
  Serial1.flush();
  char     Data_Buffer_String[5];
  int      Serial_data_count = 0;
  do
  {
    if (Serial1.available()) {
      Energy_Meter_Raw_Serial_Buffer_Data[Serial_data_count] = Serial1.read();
      Serial_data_count++;
    }
  }
  while (Energy_Meter_Raw_Serial_Buffer_Data[Serial_data_count - 1] != 'T');

  Energy_Meter_Kwh = array_to_float(Energy_Meter_Raw_Serial_Buffer_Data, 4, Data_Buffer_String);
  Serial.print ("Energy_Meter_Kwh = ");
  Serial.println (Energy_Meter_Kwh);
  //delay(100);
  ThingSpeak.writeField(myChannelNumber, 4,Energy_Meter_Kwh, myWriteAPIKey);

  Energy_Meter_Current =   array_to_float(&Energy_Meter_Raw_Serial_Buffer_Data[28], 4, Data_Buffer_String);
  Serial.print ("Energy_Meter_Current = ");
  Serial.println (Energy_Meter_Current);
  //delay(100);
  ThingSpeak.writeField(myChannelNumber, 2,Energy_Meter_Current, myWriteAPIKey);

  Energy_Meter_Watt =   array_to_float(&Energy_Meter_Raw_Serial_Buffer_Data[40], 4, Data_Buffer_String);
  Serial.print ("Energy_Meter_Watt = ");
  Serial.println (Energy_Meter_Watt);
  //delay(100);
  ThingSpeak.writeField(myChannelNumber, 3,Energy_Meter_Watt, myWriteAPIKey);

  Energy_Meter_Voltage =   array_to_float(&Energy_Meter_Raw_Serial_Buffer_Data[52], 4, Data_Buffer_String);
  Serial.print ("Energy_Meter_Voltage = ");
  Serial.println (Energy_Meter_Voltage);
 // delay(100);
  ThingSpeak.writeField(myChannelNumber, 1,Energy_Meter_Voltage, myWriteAPIKey);
  //delay(100);

  Energy_Meter_Ready_Status_flag = 1;
}


float array_to_float(char array[], unsigned int len, char buffer[])
{
  for (unsigned int i = 0; i < len; i++)  {
    byte nib1 = (array[i] >> 4) & 0x0F;
    byte nib2 = (array[i] >> 0) & 0x0F;
    buffer[i * 2 + 0] = nib1  < 0xA ? '0' + nib1  : 'A' + nib1  - 0xA;
    buffer[i * 2 + 1] = nib2  < 0xA ? '0' + nib2  : 'A' + nib2  - 0xA;
  }
  buffer[len * 2] = '\0';
  data.i = strtoul(buffer, NULL, 16);
  return data.f;
}
