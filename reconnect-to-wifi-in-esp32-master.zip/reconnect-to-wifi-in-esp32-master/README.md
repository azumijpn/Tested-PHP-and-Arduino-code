# reconnect-to-wifi-in-esp32
#include <WiFi.h>
const char* ssid = "My SSID";
const char* password = "My PW";
void setup() {
int NAcounts=0;
Serial.begin(115200);

WiFi.begin(ssid, password);
Serial.println("Connecting");
while (WiFi.status() != WL_CONNECTED && NAcounts < 7 )
{
delay(500);
Serial.print(".");
NAcounts ++;
}
if (WiFi.status() != WL_CONNECTED){
Serial.println("Resetting");
ESP.restart();
}
else
{
Serial.println("");
Serial.print("Connected to WiFi network with IP Address: ");
Serial.println(WiFi.localIP());
}
}
